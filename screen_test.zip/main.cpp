//<App !Start!>
// FILE: [main.cpp]
// Created by GUIslice Builder version: [0.17.b24]
//
// GUIslice Builder Generated File
//
// For the latest guides, updates and support view:
// https://github.com/ImpulseAdventure/GUIslice
//
//<App !End!>

// ------------------------------------------------
// Headers to include
// ------------------------------------------------
#include "test2_GSLC.h"
#include <math.h>

// ------------------------------------------------
// Program Globals
// ------------------------------------------------

// Save some element references for direct access
//<Save_References !Start!>
gslc_tsElemRef *m_pElem_power = NULL;
gslc_tsElemRef *m_pElem_north = NULL;
gslc_tsElemRef *m_pElem_T = NULL;
gslc_tsElemRef *m_pElem_RH = NULL;
gslc_tsElemRef *m_pElem_P = NULL;
gslc_tsElemRef *m_pElem_Alti = NULL;
gslc_tsElemRef *m_pElem_mag_x = NULL;
gslc_tsElemRef *m_pElem_mag_y = NULL;
gslc_tsElemRef *m_pElem_mag_z = NULL;
gslc_tsElemRef *m_pElem_conn = NULL;
//<Save_References !End!>

// Define debug message function
static int16_t DebugOut(char ch)
{
  if (ch == (char)'\n')
    Serial.println("");
  else
    Serial.write(ch);
  return 0;
}

// ------------------------------------------------
// Callback Methods
// ------------------------------------------------
//<Button Callback !Start!>
//<Button Callback !End!>
//<Checkbox Callback !Start!>
//<Checkbox Callback !End!>
//<Keypad Callback !Start!>
//<Keypad Callback !End!>
//<Spinner Callback !Start!>
//<Spinner Callback !End!>
//<Listbox Callback !Start!>
//<Listbox Callback !End!>
//<Draw Callback !Start!>
//<Draw Callback !End!>
//<Slider Callback !Start!>
//<Slider Callback !End!>
//<Tick Callback !Start!>
//<Tick Callback !End!>

void setup()
{
  // ------------------------------------------------
  // Initialize
  // ------------------------------------------------
  Serial.begin(9600);
  // Wait for USB Serial
  // delay(1000);  // NOTE: Some devices require a delay after Serial.begin() before serial port can be used

  gslc_InitDebug(&DebugOut);

  // ------------------------------------------------
  // Create graphic elements
  // ------------------------------------------------
  InitGUIslice_gen();
}

// -----------------------------------
// Main event loop
// -----------------------------------
int power_count = 0;
int redraw = 0;
void loop()
{
  char acTxt[7];

  // ------------------------------------------------
  // Update GUI Elements
  // ------------------------------------------------

  // TODO - Add update code for any text, gauges, or sliders
  if (redraw == 0)
  {
    gslc_ElemXRampSetVal(&m_gui, m_pElem_power, power_count % 100 + 1);
    gslc_ElemXRadialSetVal(&m_gui, m_pElem_north, power_count % 360 + 1);
    redraw = 1;
  }

  else if (redraw == 1)
  {
    snprintf(acTxt, 5, "%f", 20 + 10 * sin(power_count / 2.5));
    gslc_ElemSetTxtStr(&m_gui, m_pElem_T, acTxt);

    snprintf(acTxt, 6, "%f", 50 + 20 * cos(power_count / 2.5));
    gslc_ElemSetTxtStr(&m_gui, m_pElem_RH, acTxt);

    snprintf(acTxt, 7, "%f", 100 + 10 * cos(power_count / 2.5));
    gslc_ElemSetTxtStr(&m_gui, m_pElem_P, acTxt);

    snprintf(acTxt, 7, "%f", 1600 + 100 * cos(power_count / 2.5));
    gslc_ElemSetTxtStr(&m_gui, m_pElem_Alti, acTxt);

    redraw = 2;
  }
  else if (redraw == 2)
  {
    snprintf(acTxt, 4, "%f", roundf(40 * cos(power_count % 10 / 2.5)));
    gslc_ElemSetTxtStr(&m_gui, m_pElem_mag_x, acTxt);

    snprintf(acTxt, 4, "%f", roundf(40 * cos(power_count % 10 / 1.5)));
    gslc_ElemSetTxtStr(&m_gui, m_pElem_mag_y, acTxt);

    snprintf(acTxt, 4, "%f", roundf(40 * cos(power_count % 10 / 3.5)));
    gslc_ElemSetTxtStr(&m_gui, m_pElem_mag_z, acTxt);

    redraw = 3;
  }
  else
  {
    if (power_count % 0xff < 0xff / 2)
    {
      snprintf(acTxt, 4, (char *)"ON!");
    }
    else
    {
      snprintf(acTxt, 4, (char *)"OFF");
    }
    gslc_ElemSetTxtStr(&m_gui, m_pElem_conn, acTxt);

    redraw = 0;
  }

  // 动点底盘
  gslc_DrawFillRoundRect(&m_gui, (gslc_tsRect){(int16_t)(30), (int16_t)(70), 140, 140}, 10, GSLC_COL_BLUE);
  // 动点
  gslc_DrawFillCircle(&m_gui, 100 + 40.0 * (sin(power_count / 2.5)), 140 + 40.0 * (cos(power_count / 1.75)), 5, GSLC_COL_RED);

  // 动点底盘三角 左 右 上 下
  gslc_DrawFillTriangle(&m_gui, 20, 135, 29, 140, 20, 145, GSLC_COL_WHITE);
  gslc_DrawFillTriangle(&m_gui, 178, 135, 171, 140, 178, 145, GSLC_COL_WHITE);
  gslc_DrawFillTriangle(&m_gui, 95, 61, 100, 69, 105, 61, GSLC_COL_WHITE);
  gslc_DrawFillTriangle(&m_gui, 95, 219, 100, 211, 105, 219, GSLC_COL_WHITE);

  // ------------------------------------------------
  // Periodically call GUIslice update function
  // ------------------------------------------------
  gslc_Update(&m_gui);

  power_count++;
}
